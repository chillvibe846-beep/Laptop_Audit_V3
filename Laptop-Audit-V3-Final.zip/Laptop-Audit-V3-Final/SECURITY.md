# Security Policy

## Scope

This tool is an inventory helper. Run it only on devices you own or are authorized to audit.

## Data handling

Reports can contain serial numbers, computer names, MAC addresses, IP addresses, software names, domain information, and local administrator names. Treat reports as confidential internal IT data.

Never commit real audit reports, credentials, BitLocker recovery keys, private keys, browser data, or tokens.

## Reporting an issue

Do not publish sensitive details in a public issue. Contact the repository owner privately with reproduction steps and the affected version.
