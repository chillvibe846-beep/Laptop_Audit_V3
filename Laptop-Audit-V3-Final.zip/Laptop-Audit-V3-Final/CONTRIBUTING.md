# Contributing

1. Create a feature branch.
2. Keep the script compatible with supported Windows PowerShell environments.
3. Preserve existing report fields unless a documented breaking change is intended.
4. Do not add credential collection or personal-file collection.
5. Test on an authorized Windows 10/11 device.
6. Update README, documentation, and CHANGELOG when behavior changes.
7. Never commit real audit output.
