# Usage

Open PowerShell as Administrator, then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
Set-Location "<repository>\\src"
.\\Laptop_Audit.ps1
```

Reports are written to the detected Desktop under `Laptop_Audit_Reports`:

- Main CSV report
- Human-readable TXT report
- Installed software CSV

The friendly asset name is `GEPL-Maintenance`; it does not rename Windows.
