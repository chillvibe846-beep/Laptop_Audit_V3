# Troubleshooting

## Desktop not found

Run from a normal Windows user profile with a valid Desktop folder. The script checks standard Desktop and OneDrive Desktop locations.

## Battery error

Battery providers vary by device. A missing or failed battery query is treated as unavailable and does not necessarily indicate a defective battery.

## Access denied

Use an elevated PowerShell window. Some Windows security, TPM, Defender, BitLocker, and administrator queries require elevation.

## Reports are missing

Check the Desktop folder selected by the script and open `Laptop_Audit_Reports`.
