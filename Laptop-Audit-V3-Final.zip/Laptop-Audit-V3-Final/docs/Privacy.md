# Privacy and Data Handling

The script is intended for authorized IT asset inventory. It does not intentionally collect passwords or BitLocker recovery keys. However, reports may contain device identifiers, network identifiers, software inventory, domain information, and local administrator names.

Store reports only in approved company locations. Redact serial numbers, MAC addresses, IP addresses, and user/account names before external sharing.
