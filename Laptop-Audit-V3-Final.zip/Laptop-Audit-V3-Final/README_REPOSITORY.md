# Laptop Audit Final V3 Repository

This repository packages the complete `src/Laptop_Audit.ps1` script and its operational documentation.

## Structure

- `src/` — production PowerShell script
- `docs/` — usage, privacy, and troubleshooting
- `tests/` — validation checklist
- `examples/` — sanitized examples only
- `SECURITY.md` — security and data handling policy
- `CONTRIBUTING.md` — contribution rules

See the main `README.md` for the full audit field and usage documentation.
