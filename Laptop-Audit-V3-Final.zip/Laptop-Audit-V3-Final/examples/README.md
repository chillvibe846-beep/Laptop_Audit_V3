# Examples

Only sanitized example reports belong here. Never place real serial numbers, MAC addresses, IP addresses, user names, domain names, or company software inventories in this directory.
