# Test Checklist

This repository contains a hardware inventory script rather than a unit-testable module. Validate on an authorized Windows 10/11 test device:

- [ ] Script parses without syntax errors.
- [ ] CSV and TXT reports are created.
- [ ] Installed software CSV is created.
- [ ] Existing report files remain untouched.
- [ ] Desktop detection works with and without OneDrive.
- [ ] Battery-unavailable systems complete without stopping.
- [ ] TPM, Secure Boot, BitLocker, Defender, and firewall fields degrade to `Not Available` when unsupported.
- [ ] No passwords or recovery keys appear in output.
