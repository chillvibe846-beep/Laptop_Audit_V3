# Changelog

## [3.0.0] - 2026-09-15

- Packaged the complete Laptop Audit Final V3 PowerShell script.
- Preserved hardware, Windows, security, network, battery, identity, and software inventory fields.
- Added professional repository documentation and contribution/security guidance.
- Added Git exclusions for audit reports and sensitive device data.
