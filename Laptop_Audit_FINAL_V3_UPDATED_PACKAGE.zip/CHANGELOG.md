# Changelog

## Updated V3
- Windows 7/10/11 compatibility
- HDD/SSD and logical-drive collection
- Exact date/time
- Installed software export
