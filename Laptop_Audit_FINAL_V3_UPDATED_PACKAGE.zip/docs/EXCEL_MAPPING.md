Import the main CSV into the technical inventory sheet. Import Installed_Software CSV into the software sheet. Enter asset ID, purchase, vendor, warranty, assignment and physical QC manually.
