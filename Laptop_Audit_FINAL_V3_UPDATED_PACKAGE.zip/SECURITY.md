# Security
Review reports before sharing. They may contain serial numbers, usernames, IP addresses and installed software. Passwords and BitLocker recovery keys are not collected.
