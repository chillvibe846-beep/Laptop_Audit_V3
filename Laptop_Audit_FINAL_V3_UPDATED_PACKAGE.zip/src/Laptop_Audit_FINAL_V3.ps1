#requires -version 2.0
$ErrorActionPreference = "SilentlyContinue"

function S($v) {
    if ($null -eq $v) { return "Not Available" }
    $x = [string]$v
    if ([string]::IsNullOrWhiteSpace($x)) { return "Not Available" }
    return ($x -replace "`r|`n"," ").Trim()
}
function F($a) {
    foreach ($v in $a) {
        if ($null -ne $v -and -not [string]::IsNullOrWhiteSpace([string]$v)) { return S $v }
    }
    return "Not Available"
}
function W($c,$n="root\cimv2") {
    try { Get-WmiObject -Namespace $n -Class $c -ErrorAction SilentlyContinue } catch { $null }
}

$now = Get-Date
$stamp = $now.ToString("yyyyMMdd_HHmmss")
$computer = $env:COMPUTERNAME
$desktop = [Environment]::GetFolderPath("Desktop")
$out = Join-Path $desktop "Laptop_Audit_Reports"
if (!(Test-Path $out)) { New-Item $out -ItemType Directory -Force | Out-Null }

$cs=W "Win32_ComputerSystem"; $bios=W "Win32_BIOS"; $os=W "Win32_OperatingSystem"
$cpu=W "Win32_Processor"; $ram=W "Win32_PhysicalMemory"; $disk=W "Win32_DiskDrive"
$logical=W "Win32_LogicalDisk"; $gpu=W "Win32_VideoController"
$net=W "Win32_NetworkAdapterConfiguration"; $ad=W "Win32_NetworkAdapter"
$bat=W "Win32_Battery"

$ramTotal=0
foreach($r in @($ram)){ if($r.Capacity){$ramTotal += [math]::Round(([double]$r.Capacity/1GB),2)} }
$ramText = if($ramTotal -gt 0){"$ramTotal GB"}else{"Not Available"}

$physical=@()
foreach($d in @($disk)){
    $size=if($d.Size){"{0} GB" -f [math]::Round(([double]$d.Size/1GB),2)}else{"Not Available"}
    $physical += "Model=$(S $d.Model); Interface=$(S $d.InterfaceType); Media=$(S $d.MediaType); Serial=$(F @($d.SerialNumber,$d.PNPDeviceID)); Size=$size"
}
$logicalRows=@()
foreach($l in @($logical | Where-Object {$_.DriveType -eq 3})){
    $size=if($l.Size){"{0} GB" -f [math]::Round(([double]$l.Size/1GB),2)}else{"Not Available"}
    $free=if($l.FreeSpace){"{0} GB" -f [math]::Round(([double]$l.FreeSpace/1GB),2)}else{"Not Available"}
    $logicalRows += "Drive=$(S $l.DeviceID); FileSystem=$(S $l.FileSystem); Total=$size; Free=$free; Volume=$(S $l.VolumeName)"
}
$ips=@($net | Where-Object {$_.IPEnabled -eq $true} | ForEach-Object {
    "Adapter=$(S $_.Description); IP=$($_.IPAddress -join ', '); MAC=$(S $_.MACAddress); Gateway=$($_.DefaultIPGateway -join ', ')"
})

$activation="Not Available"
try {
    $lic=Get-WmiObject -Query "SELECT LicenseStatus FROM SoftwareLicensingProduct WHERE PartialProductKey IS NOT NULL"
    if(@($lic | Where-Object {$_.LicenseStatus -eq 1}).Count -gt 0){$activation="Activated"}
} catch {}

$tpm="Not Available"
try { if(Get-WmiObject -Namespace "root\cimv2\Security\MicrosoftTpm" -Class Win32_Tpm){$tpm="Present"} } catch {}

$office="Not Detected"
try {
    $keys=Get-ItemProperty "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue |
      Where-Object {$_.DisplayName -match "Microsoft Office|Microsoft 365"}
    if($keys){$office=(@($keys | ForEach-Object {$_.DisplayName}) -join ", ")}
} catch {}

$rows=@(
 [pscustomobject]@{Item="Audit Date";Value=$now.ToString("yyyy-MM-dd")}
 [pscustomobject]@{Item="Audit Time";Value=$now.ToString("HH:mm:ss")}
 [pscustomobject]@{Item="Computer Name";Value=$computer}
 [pscustomobject]@{Item="Logged-in User";Value=$env:USERNAME}
 [pscustomobject]@{Item="OS Name";Value=(S $os.Caption)}
 [pscustomobject]@{Item="OS Version";Value=(S $os.Version)}
 [pscustomobject]@{Item="OS Build";Value=(S $os.BuildNumber)}
 [pscustomobject]@{Item="OS Architecture";Value=(S $os.OSArchitecture)}
 [pscustomobject]@{Item="Manufacturer";Value=(S $cs.Manufacturer)}
 [pscustomobject]@{Item="Model";Value=(S $cs.Model)}
 [pscustomobject]@{Item="Serial Number";Value=(F @($bios.SerialNumber,$cs.IdentifyingNumber))}
 [pscustomobject]@{Item="Processor";Value=((@($cpu | ForEach-Object {$_.Name})) -join " || ")}
 [pscustomobject]@{Item="CPU Cores";Value=((@($cpu | ForEach-Object {$_.NumberOfCores})) -join ", ")}
 [pscustomobject]@{Item="CPU Threads";Value=((@($cpu | ForEach-Object {$_.NumberOfLogicalProcessors})) -join ", ")}
 [pscustomobject]@{Item="CPU Max Clock MHz";Value=((@($cpu | ForEach-Object {$_.MaxClockSpeed})) -join ", ")}
 [pscustomobject]@{Item="BIOS";Value="$(S $bios.SMBIOSBIOSVersion); Date=$(S $bios.ReleaseDate)"}
 [pscustomobject]@{Item="RAM Installed";Value=$ramText}
 [pscustomobject]@{Item="RAM Module Count";Value=@($ram).Count}
 [pscustomobject]@{Item="Physical HDD/SSD";Value=if($physical.Count){$physical -join " || "}else{"Not Available"}}
 [pscustomobject]@{Item="Logical Drives";Value=if($logicalRows.Count){$logicalRows -join " || "}else{"Not Available"}}
 [pscustomobject]@{Item="GPU";Value=((@($gpu | ForEach-Object {$_.Name})) -join " || ")}
 [pscustomobject]@{Item="Network";Value=if($ips.Count){$ips -join " || "}else{"Not Available"}}
 [pscustomobject]@{Item="Windows Activation";Value=$activation}
 [pscustomobject]@{Item="TPM";Value=$tpm}
 [pscustomobject]@{Item="Microsoft Office";Value=$office}
 [pscustomobject]@{Item="Domain/Workgroup";Value=(F @($cs.Domain,$cs.Workgroup))}
 [pscustomobject]@{Item="Part Of Domain";Value=(S $cs.PartOfDomain)}
 [pscustomobject]@{Item="Battery";Value=(F @($bat.Name,$bat.Description))}
 [pscustomobject]@{Item="Last Boot";Value=(S $os.LastBootUpTime)}
 [pscustomobject]@{Item="Passwords/Recovery Keys";Value="Not Collected"}
)

$csv=Join-Path $out "Laptop_Audit_${computer}_${stamp}.csv"
$txt=Join-Path $out "Laptop_Audit_${computer}_${stamp}.txt"
$rows | Export-Csv $csv -NoTypeInformation -Encoding UTF8
$rows | Format-Table -AutoSize | Out-String -Width 240 | Set-Content $txt -Encoding UTF8

$software=@()
foreach($p in @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*","HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*","HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*")){
    $software += Get-ItemProperty $p -ErrorAction SilentlyContinue | Where-Object {$_.DisplayName} |
      Select-Object DisplayName,DisplayVersion,Publisher,InstallDate,InstallLocation,EstimatedSize
}
$software | Sort-Object DisplayName -Unique | Export-Csv (Join-Path $out "Installed_Software_${computer}_${stamp}.csv") -NoTypeInformation -Encoding UTF8

Write-Host "GENLITE LAPTOP AUDIT FINAL V3 COMPLETED" -ForegroundColor Green
Write-Host "CSV: $csv" -ForegroundColor Yellow
Write-Host "TXT: $txt" -ForegroundColor Yellow
Write-Host "No passwords or BitLocker recovery keys were collected." -ForegroundColor Green
