# Contributing
Report OS version, PowerShell version, error text and missing field.
