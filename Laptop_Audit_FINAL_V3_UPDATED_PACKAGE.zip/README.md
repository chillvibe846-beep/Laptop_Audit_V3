# Genlite Laptop Audit FINAL V3 Updated

Compatible target: Windows 7, Windows 10 and Windows 11 with Windows PowerShell.

## Run
1. Copy `src\Laptop_Audit_FINAL_V3.ps1` to the laptop Desktop.
2. Open PowerShell as Administrator.
3. Run:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
cd "$env:USERPROFILE\Desktop"
.\Laptop_Audit_FINAL_V3.ps1
```

Reports are saved in `Desktop\Laptop_Audit_Reports`.

The script collects hardware, HDD/SSD and logical-drive details, Windows information,
RAM, CPU, network, software, domain/workgroup, battery and audit date/time.
Unsupported values show `Not Available`.

It does not collect passwords or BitLocker recovery keys.
