# ============================================================
# LAPTOP AUDIT - WINDOWS 7 / 10 / 11 COMPATIBLE
# Office IT Asset Management
# Run PowerShell as Administrator
#
# Uses legacy WMI and registry methods so it can run on:
# - Windows 7 with PowerShell 2.0+
# - Windows 10
# - Windows 11
#
# Some modern security fields are reported as Not Available on
# Windows 7 because the operating system does not support them.
# ============================================================

param(
    [string]$AssetName = ""
)

$ErrorActionPreference = "SilentlyContinue"

function Safe-Value {
    param(
        [object]$Value,
        [string]$Default = "Not Available"
    )

    if ($null -eq $Value) { return $Default }

    $text = [string]$Value
    $text = $text.Trim()

    if ($text -eq "" -or $text -match "^(x+|unknown|null|n/a|not available)$") {
        return $Default
    }

    return $text
}

function Yes-No {
    param([object]$Value)

    if ($null -eq $Value) { return "Not Available" }
    if ([string]$Value -eq "True") { return "Yes" }
    if ([string]$Value -eq "False") { return "No" }

    return (Safe-Value $Value)
}

function Get-FirstValue {
    param(
        [object]$Object,
        [string]$Property
    )

    if ($null -eq $Object) { return "Not Available" }

    try {
        return (Safe-Value $Object.$Property)
    }
    catch {
        return "Not Available"
    }
}

function Convert-WmiDate {
    param([object]$Value)

    if ($null -eq $Value) { return "Not Available" }

    try {
        return ([Management.ManagementDateTimeConverter]::ToDateTime([string]$Value)).ToString("yyyy-MM-dd HH:mm:ss")
    }
    catch {
        return "Not Available"
    }
}

function Get-DesktopPath {
    $paths = @(
        [Environment]::GetFolderPath("Desktop"),
        "$env:USERPROFILE\Desktop",
        "$env:USERPROFILE\OneDrive\Desktop",
        "$env:USERPROFILE\OneDrive - Genlite - Personal\Desktop",
        "$env:USERPROFILE\OneDrive - Genlite\Desktop"
    )

    foreach ($path in $paths) {
        if ($path -and (Test-Path $path)) {
            return $path
        }
    }

    return $null
}

function Get-RegistryValue {
    param(
        [string]$Path,
        [string]$Name
    )

    try {
        $item = Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue
        if ($item) {
            return (Safe-Value $item.$Name)
        }
    }
    catch {}

    return "Not Available"
}

$now = Get-Date
$timestamp = $now.ToString("yyyyMMdd_HHmmss")

if ([string]::IsNullOrWhiteSpace($AssetName)) {
    $AssetName = $env:COMPUTERNAME
}
$AssetName = Safe-Value $AssetName $env:COMPUTERNAME

$desktop = Get-DesktopPath
if (-not $desktop) {
    Write-Host "ERROR: Desktop folder was not found." -ForegroundColor Red
    exit 1
}

$outDir = Join-Path $desktop "Laptop_Audit_Reports"
New-Item -ItemType Directory -Path $outDir -Force | Out-Null

# -------------------------
# WMI collection
# -------------------------
$computer = Get-WmiObject Win32_ComputerSystem
$bios = Get-WmiObject Win32_BIOS
$os = Get-WmiObject Win32_OperatingSystem
$cpu = Get-WmiObject Win32_Processor | Select-Object -First 1
$ramModules = @(Get-WmiObject Win32_PhysicalMemory)
$disks = @(Get-WmiObject Win32_DiskDrive)
$logicalDisks = @(Get-WmiObject Win32_LogicalDisk -Filter "DriveType=3")
$gpus = @(Get-WmiObject Win32_VideoController)
$netAdapters = @(Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled=True")
$battery = @(Get-WmiObject Win32_Battery)

# -------------------------
# Identity
# -------------------------
$manufacturer = Get-FirstValue $computer "Manufacturer"
$model = Get-FirstValue $computer "Model"
$serial = Get-FirstValue $bios "SerialNumber"
$windowsComputerName = Safe-Value $env:COMPUTERNAME

# -------------------------
# CPU
# -------------------------
$cpuName = Get-FirstValue $cpu "Name"
$cpuCores = Get-FirstValue $cpu "NumberOfCores"
$cpuThreads = Get-FirstValue $cpu "NumberOfLogicalProcessors"

$cpuMaxGHz = "Not Available"
try {
    if ($cpu.MaxClockSpeed) {
        $cpuMaxGHz = "{0:N2} GHz" -f ([double]$cpu.MaxClockSpeed / 1000)
    }
}
catch {}

# -------------------------
# RAM
# -------------------------
$ramGB = "Not Available"
try {
    if ($computer.TotalPhysicalMemory) {
        $ramGB = "{0:N2} GB" -f ([double]$computer.TotalPhysicalMemory / 1GB)
    }
}
catch {}

$ramCount = $ramModules.Count
if ($ramCount -eq 0) { $ramCount = "Not Available" }

$ramTypes = @()
foreach ($ram in $ramModules) {
    $type = "Not Available"
    try {
        $type = switch ([int]$ram.SMBIOSMemoryType) {
            20 { "DDR" }
            21 { "DDR2" }
            22 { "DDR2 FB-DIMM" }
            24 { "DDR3" }
            26 { "DDR4" }
            34 { "DDR5" }
            default { "Not Available" }
        }
    }
    catch {}
    $ramTypes += $type
}
$ramType = Safe-Value (($ramTypes | Sort-Object -Unique) -join ", ")

# -------------------------
# Storage
# -------------------------
$physicalStorageGB = "Not Available"
try {
    $sizes = @($disks | Where-Object { $_.Size } | ForEach-Object { [double]$_.Size })
    if ($sizes.Count -gt 0) {
        $physicalStorageGB = "{0:N2} GB" -f (($sizes | Measure-Object -Sum).Sum / 1GB)
    }
}
catch {}

$storageModel = Safe-Value (($disks | ForEach-Object { $_.Model } | Where-Object { $_ } | Sort-Object -Unique) -join "; ")
$storageSerial = Safe-Value (($disks | ForEach-Object { $_.SerialNumber } | Where-Object { $_ } | Sort-Object -Unique) -join "; ")

$totalLogicalGB = "Not Available"
$freeSpaceGB = "Not Available"
try {
    if ($logicalDisks.Count -gt 0) {
        $totalLogicalGB = "{0:N2} GB" -f ((($logicalDisks | Measure-Object Size -Sum).Sum) / 1GB)
        $freeSpaceGB = "{0:N2} GB" -f ((($logicalDisks | Measure-Object FreeSpace -Sum).Sum) / 1GB)
    }
}
catch {}

# -------------------------
# GPU
# -------------------------
$gpu = Safe-Value (($gpus | ForEach-Object { $_.Name } | Where-Object { $_ } | Sort-Object -Unique) -join "; ")

# -------------------------
# Monitor - WMI if available
# -------------------------
$monitorInfo = "Not Available"
try {
    $monitorIds = @(Get-WmiObject -Namespace root\wmi -Class WmiMonitorID)
    $monitorNames = @()

    foreach ($monitor in $monitorIds) {
        if ($monitor.UserFriendlyName) {
            $name = -join ($monitor.UserFriendlyName | Where-Object { $_ -ne 0 } | ForEach-Object { [char]$_ })
            if ($name) { $monitorNames += $name }
        }
    }

    $monitorInfo = Safe-Value (($monitorNames | Sort-Object -Unique) -join "; ")
}
catch {}

# -------------------------
# Windows
# -------------------------
$windowsEdition = Get-FirstValue $os "Caption"
$windowsVersion = Get-FirstValue $os "Version"
$windowsBuild = Get-FirstValue $os "BuildNumber"
$architecture = Get-FirstValue $os "OSArchitecture"

# Windows 7-compatible activation check
$activation = "Not Available"
try {
    $licenseProducts = Get-WmiObject -Class SoftwareLicensingProduct |
        Where-Object { $_.Name -like "Windows*" -and $_.PartialProductKey }

    $license = $licenseProducts | Sort-Object LicenseStatus -Descending | Select-Object -First 1

    if ($license) {
        $activation = switch ([int]$license.LicenseStatus) {
            1 { "Activated" }
            0 { "Unlicensed" }
            default { "Not Available" }
        }
    }
}
catch {}

# -------------------------
# Office detection
# -------------------------
$officeDetected = "Not Detected"
$officePaths = @(
    "$env:ProgramFiles\Microsoft Office",
    "$env:ProgramFiles\Microsoft Office\Office14",
    "$env:ProgramFiles\Microsoft Office\Office15",
    "$env:ProgramFiles\Microsoft Office\Office16",
    "${env:ProgramFiles(x86)}\Microsoft Office",
    "${env:ProgramFiles(x86)}\Microsoft Office\Office14",
    "${env:ProgramFiles(x86)}\Microsoft Office\Office15",
    "${env:ProgramFiles(x86)}\Microsoft Office\Office16"
)

foreach ($path in $officePaths) {
    if ($path -and (Test-Path $path)) {
        $officeDetected = "Detected"
    }
}

# -------------------------
# TPM - legacy WMI attempt
# -------------------------
$tpmPresent = "Not Available"
$tpmReady = "Not Available"
$tpmVersion = "Not Available"

try {
    $tpm = Get-WmiObject -Namespace root\cimv2\Security\MicrosoftTpm -Class Win32_Tpm
    if ($tpm) {
        $tpmPresent = "Yes"
        $tpmReady = "Not Available"
        $tpmVersion = Safe-Value $tpm.SpecVersion
    }
}
catch {}

# -------------------------
# Secure Boot
# -------------------------
# Secure Boot is not supported on Windows 7 and may be unavailable
$secureBoot = "Not Available"

# -------------------------
# BitLocker
# -------------------------
$bitlockerStatus = "Not Available"
$bitlockerPercent = "Not Available"

try {
    $manageBde = "$env:SystemRoot\System32\manage-bde.exe"
    if (Test-Path $manageBde) {
        $blText = & $manageBde -status $env:SystemDrive 2>$null | Out-String

        if ($blText -match "Fully Encrypted|Fully Encrypted") {
            $bitlockerStatus = "Fully Encrypted"
        }
        elseif ($blText -match "Protection On") {
            $bitlockerStatus = "Protection On"
        }
        elseif ($blText -match "Protection Off") {
            $bitlockerStatus = "Protection Off"
        }
        elseif ($blText -match "Conversion Status") {
            $bitlockerStatus = "Detected - Check Details"
        }

        if ($blText -match "Percentage Encrypted:\s+([0-9]+)%") {
            $bitlockerPercent = "$($matches[1])%"
        }
    }
}
catch {}

# -------------------------
# Defender / Firewall
# -------------------------
$defenderStatus = "Not Available"
$realTimeProtection = "Not Available"

# Windows 7 generally does not provide Get-MpComputerStatus
try {
    $defenderService = Get-Service WinDefend
    if ($defenderService) {
        $defenderStatus = Safe-Value $defenderService.Status
    }
}
catch {}

$firewall = "Not Available"
try {
    $firewallProfiles = Get-WmiObject -Namespace root\SecurityCenter2 -Class FirewallProduct
    if ($firewallProfiles) {
        $firewall = "Detected"
    }
}
catch {}

# -------------------------
# Network
# -------------------------
$wifi = @($netAdapters | Where-Object { $_.Description -match "Wi-Fi|Wireless|802.11" })
$ethernet = @($netAdapters | Where-Object { $_.Description -notmatch "Wi-Fi|Wireless|802.11" })

$wifiIP = Safe-Value (($wifi | ForEach-Object { $_.IPAddress } | Where-Object { $_ } | ForEach-Object { $_ -join ", " }) -join "; ")
$wifiMAC = Safe-Value (($wifi | ForEach-Object { $_.MACAddress } | Where-Object { $_ }) -join ", ")
$ethernetIP = Safe-Value (($ethernet | ForEach-Object { $_.IPAddress } | Where-Object { $_ } | ForEach-Object { $_ -join ", " }) -join "; ")
$ethernetMAC = Safe-Value (($ethernet | ForEach-Object { $_.MACAddress } | Where-Object { $_ }) -join ", ")

$bluetooth = "Not Available"
try {
    $bt = Get-WmiObject Win32_PnPEntity | Where-Object { $_.Name -match "Bluetooth" }
    if ($bt) { $bluetooth = "Detected" }
}
catch {}

# -------------------------
# Battery
# -------------------------
$batteryStatus = "Not Available"
if ($battery.Count -gt 0) {
    $batteryStatus = Safe-Value (($battery | ForEach-Object { $_.Status } | Sort-Object -Unique) -join ", ")
}

$designCapacity = "Not Available"
$fullChargeCapacity = "Not Available"
$batteryHealth = "Not Available"

try {
    $batStatic = @(Get-WmiObject -Namespace root\wmi -Class BatteryStaticData)
    $batFull = @(Get-WmiObject -Namespace root\wmi -Class BatteryFullChargedCapacity)

    if ($batStatic.Count -gt 0 -and $batStatic[0].DesignedCapacity) {
        $designCapacity = "{0:N0} mWh" -f $batStatic[0].DesignedCapacity
    }

    if ($batFull.Count -gt 0 -and $batFull[0].FullChargedCapacity) {
        $fullChargeCapacity = "{0:N0} mWh" -f $batFull[0].FullChargedCapacity
    }

    if ($batStatic.Count -gt 0 -and $batFull.Count -gt 0) {
        $d = [double]$batStatic[0].DesignedCapacity
        $f = [double]$batFull[0].FullChargedCapacity

        if ($d -gt 0) {
            $batteryHealth = "{0:N1}%" -f (($f / $d) * 100)
        }
    }
}
catch {}

# -------------------------
# Domain
# -------------------------
$domain = Get-FirstValue $computer "Domain"
$domainJoined = Yes-No $computer.PartOfDomain

# Entra ID does not exist on normal Windows 7
$entraJoined = "Not Supported on Windows 7"

# -------------------------
# Local administrators - compatible with Windows 7
# -------------------------
$localAdmins = "Not Available"
try {
    $adminGroup = [ADSI]"WinNT://$env:COMPUTERNAME/Administrators,group"
    $members = @($adminGroup.psbase.Invoke("Members"))

    $names = @()
    foreach ($member in $members) {
        $names += $member.GetType().InvokeMember("Name", "GetProperty", $null, $member, $null)
    }

    $localAdmins = Safe-Value ($names -join "; ")
}
catch {}

# -------------------------
# BIOS / boot
# -------------------------
$biosVersion = Get-FirstValue $bios "SMBIOSBIOSVersion"
$biosDate = Convert-WmiDate $bios.ReleaseDate
$lastBoot = Convert-WmiDate $os.LastBootUpTime

# -------------------------
# USB / webcam
# -------------------------
$usbCount = "Not Available"
try {
    $usbCount = @(Get-WmiObject Win32_PnPEntity | Where-Object { $_.PNPClass -eq "USB" }).Count
}
catch {}

$webcam = "Not Available"
try {
    $camera = Get-WmiObject Win32_PnPEntity | Where-Object { $_.Name -match "Camera|Webcam|Integrated Camera" }
    if ($camera) { $webcam = "Detected" }
    else { $webcam = "Not Detected" }
}
catch {}

# -------------------------
# Latest hotfix
# -------------------------
$lastHotfix = "Not Available"
try {
    $hotfix = Get-WmiObject Win32_QuickFixEngineering |
        Where-Object { $_.InstalledOn } |
        Sort-Object InstalledOn -Descending |
        Select-Object -First 1

    if ($hotfix.InstalledOn) {
        $lastHotfix = Safe-Value $hotfix.InstalledOn
    }
}
catch {}

# -------------------------
# Installed software inventory
# -------------------------
$softwareList = @()
$registryPaths = @(
    "HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",
    "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\*"
)

foreach ($path in $registryPaths) {
    try {
        $softwareList += Get-ItemProperty $path -ErrorAction SilentlyContinue |
            Where-Object { $_.DisplayName -and $_.SystemComponent -ne 1 } |
            ForEach-Object {
                New-Object PSObject -Property @{
                    SoftwareName = Safe-Value $_.DisplayName
                    Version = Safe-Value $_.DisplayVersion
                    Publisher = Safe-Value $_.Publisher
                    InstallDate = Safe-Value $_.InstallDate
                    InstallLocation = Safe-Value $_.InstallLocation
                    EstimatedSizeMB = if ($_.EstimatedSize) { [math]::Round($_.EstimatedSize / 1024, 2) } else { "Not Available" }
                }
            }
    }
    catch {}
}

$softwareList = @($softwareList | Sort-Object SoftwareName, Version -Unique)
$softwareCount = $softwareList.Count

$softwareCsvPath = Join-Path $outDir "Installed_Software_${AssetName}_${timestamp}.csv"
$softwareList | Export-Csv -Path $softwareCsvPath -NoTypeInformation

# -------------------------
# Report
# -------------------------
$report = [ordered]@{
    "Audit Date" = $now.ToString("yyyy-MM-dd")
    "Audit Time" = $now.ToString("HH:mm:ss")
    "Device Name" = $AssetName
    "Windows Computer Name" = $windowsComputerName
    "Manufacturer" = $manufacturer
    "Model" = $model
    "Serial Number" = $serial
    "BIOS Version" = $biosVersion
    "BIOS Date" = $biosDate
    "Processor" = $cpuName
    "CPU Cores" = $cpuCores
    "CPU Threads" = $cpuThreads
    "CPU Max Speed" = $cpuMaxGHz
    "RAM" = $ramGB
    "RAM Type" = $ramType
    "RAM Module Count" = $ramCount
    "Storage Total (Physical)" = $physicalStorageGB
    "Storage Model" = $storageModel
    "Storage Serial" = $storageSerial
    "Logical Storage Total" = $totalLogicalGB
    "Free Storage" = $freeSpaceGB
    "GPU" = $gpu
    "Monitor" = $monitorInfo
    "Windows Edition" = $windowsEdition
    "Windows Version" = $windowsVersion
    "Windows Build" = $windowsBuild
    "OS Architecture" = $architecture
    "Windows Activation" = $activation
    "Office / M365 Detected" = $officeDetected
    "TPM Present" = $tpmPresent
    "TPM Ready" = $tpmReady
    "TPM Version" = $tpmVersion
    "Secure Boot" = $secureBoot
    "BitLocker Status" = $bitlockerStatus
    "BitLocker Encryption" = $bitlockerPercent
    "Defender" = $defenderStatus
    "Real-Time Protection" = $realTimeProtection
    "Firewall" = $firewall
    "Wi-Fi IP" = $wifiIP
    "Wi-Fi MAC" = $wifiMAC
    "Ethernet IP" = $ethernetIP
    "Ethernet MAC" = $ethernetMAC
    "Bluetooth" = $bluetooth
    "Battery Status" = $batteryStatus
    "Battery Design Capacity" = $designCapacity
    "Battery Full Charge Capacity" = $fullChargeCapacity
    "Battery Health" = $batteryHealth
    "Domain" = $domain
    "Domain Joined" = $domainJoined
    "Entra ID Joined" = $entraJoined
    "Local Administrators" = $localAdmins
    "Last Boot" = $lastBoot
    "USB Devices Available" = $usbCount
    "Webcam" = $webcam
    "Latest Hotfix Date" = $lastHotfix
    "Installed Software Count" = $softwareCount
    "Software Inventory CSV" = $softwareCsvPath
    "Report Folder" = $outDir
}

$csvPath = Join-Path $outDir "Laptop_Audit_${AssetName}_${timestamp}.csv"
[pscustomobject]$report | Export-Csv -Path $csvPath -NoTypeInformation

$txtPath = Join-Path $outDir "Laptop_Audit_${AssetName}_${timestamp}.txt"
$report.GetEnumerator() | ForEach-Object {
    "{0}: {1}" -f $_.Key, $_.Value
} | Out-File -FilePath $txtPath -Encoding UTF8

Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " WINDOWS 7/10/11 LAPTOP AUDIT COMPLETED" -ForegroundColor Green
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "Asset  : $AssetName"
Write-Host "Windows: $windowsComputerName"
Write-Host "Serial : $serial"
Write-Host "Date   : $($now.ToString('yyyy-MM-dd'))"
Write-Host "Time   : $($now.ToString('HH:mm:ss'))"
Write-Host ""
Write-Host "CSV report: $csvPath" -ForegroundColor Yellow
Write-Host "TXT report: $txtPath" -ForegroundColor Yellow
Write-Host "Software : $softwareCsvPath" -ForegroundColor Yellow
Write-Host ""
Write-Host "No passwords or BitLocker recovery keys were collected." -ForegroundColor Green
Write-Host ""
