WINDOWS 7 COMPATIBLE LAPTOP AUDIT

File:
Laptop_Audit_WINDOWS7_COMPATIBLE.ps1

Run as Administrator.

1. Open PowerShell.
2. Run:
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

3. Go to the folder containing the script:
   cd "$env:USERPROFILE\Downloads"

4. Run:
   .\Laptop_Audit_WINDOWS7_COMPATIBLE.ps1

Optional company asset name:
   .\Laptop_Audit_WINDOWS7_COMPATIBLE.ps1 -AssetName "GEPL-LAPTOP-01"

Reports are saved to:
   Desktop\Laptop_Audit_Reports

This script uses legacy WMI and registry methods for Windows 7 compatibility.
Some fields may show Not Available or Not Supported on Windows 7:
- Secure Boot
- Entra ID
- Modern Defender status
- Some TPM/BitLocker fields
- Some monitor/battery fields

It does not collect passwords or BitLocker recovery keys.
